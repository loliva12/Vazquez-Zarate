<?php
// Obtener el valor de $rol de los parámetros de consulta
if (isset($_GET['rol'])) {
    $rol = $_GET['rol'];
} else {
    // Manejar el caso en que $rol no esté definido en los parámetros de consulta
    $rol = "Valor predeterminado";
}
?>

<?php
include('ludb.php'); 

if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
    if ($DB_conn) {
        $query = "SELECT * FROM tribunales WHERE nombre LIKE '%$searchTerm%' ORDER BY nombre";
        $result = mysqli_query($DB_conn, $query);
        while ($register = mysqli_fetch_array($result)) { 
            echo "<tr>";
            echo "<td>{$register['nombre']}</td>";
            echo "<td>{$register['direccion']}</td>";
            echo "<td>{$register['telefono']}</td>";
            echo "<td>{$register['email']}</td>";
            echo "<td>{$register['otros']}</td>";
            echo "<td>";
            echo "<a href='./edit-tribunal.php?id_tribunal={$register['id_tribunal']}&rol=" . urlencode($rol) . "' class='btn btn-success' title='Editar el registro {$register['id_tribunal']}'>";
            echo "<i class='fas fa-user-edit'></i></a>";
            // Eliminar el registro
            echo "<a href='./delete-tribunal.php?id_tribunal={$register['id_tribunal']}&rol=" . urlencode($rol) . "' class='btn btn-danger' title='Borrar el registro {$register['id_tribunal']}'>";
            echo "<i class='fas fa-trash-alt'></i></a>";
            echo "</td></tr>";
        }
    } else {
        echo "Database connection not established.";
    }
}
?>
