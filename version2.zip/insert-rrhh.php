<?php
require_once ("./ludb.php");

$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$dni = $_POST["dni"];
$fecha_nacimiento = $_POST["fecha_nacimiento"];
$telefono = $_POST["telefono"];
$email = $_POST["email"];
$direccion = $_POST["direccion"];

$query = "INSERT INTO rrhh (
                id_rrhh, 
                nombre,
                apellido,
                dni, 
                fecha_nacimiento,
                telefono, 
                email,
                direccion
            ) VALUES (
                NULL, 
                '$nombre', 
                '$apellido', 
                '$dni',
                '$fecha_nacimiento',
                '$telefono',
                '$email',
                '$direccion'
            )";

if ($DB_conn->query($query) === TRUE) {
    echo '<script>alert("Registro insertado")</script>';
    // Redireccionar a crud-rrhh.php incluyendo el valor de $rol como parámetro de consulta
    if (isset($_POST['rol'])) {
        $rol = $_POST['rol'];
        header("Location: ./crud-rrhh.php?rol=" . urlencode($rol));
    } else {
        header("Location: ./crud-rrhh.php");
    }
} else {
    echo "Error: " . $query . "<br>" . $DB_conn->error;
    exit;
}

$_SESSION['message'] = "Éxito: se guardaron correctamente los datos en la base.";
$_SESSION['message_type'] = "success";
?>
