<!-- Comienza código: insert.php -->
<?PHP
require_once ("./ludb.php");

$nombre       = $_POST["nombre"];
$direccion      = $_POST["direccion"];
$telefono      = $_POST["telefono"];
$email     = $_POST["email"];

  $query = "INSERT 
              INTO tribunales(
                  id_tribunal, 
                  nombre,
                  direccion,
                  telefono, 
                  email,
                  otros)
              VALUE (
                  NULL, 
                  '$nombre', 
                  '$direccion',
                  '$telefono',
                  '$email',
                  '$otros');";

if ($DB_conn->query($query) === TRUE) {
  echo '<script>alert("Registro insertado")</script>';

  if (isset($_POST['rol'])) {
      $rol = $_POST['rol'];
      header("Location: ./crud-tribunal.php?rol=" . urlencode($rol));
  } else {
      header("Location: ./crud-tribunal.php");
  }
} else {
  echo "Error: " . $query . "<br>" . $DB_conn->error;
  exit;
}

  $_SESSION['message'] = "Éxito: se guardaron correctamente los datos en la base.";
  $_SESSION['message_type'] = "success";

header("Location: ./crud-tribunal.php");


?>