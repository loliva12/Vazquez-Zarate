<?php
require_once("./ludb.php");

if(isset($_GET['id_rrhh'])) {
    $id_rrhh = $_GET['id_rrhh'];
    $rol = isset($_GET['rol']) ? $_GET['rol'] : "Valor predeterminado"; // Obtener el valor de $rol de los parámetros de consulta

    $query = "DELETE FROM rrhh WHERE id_rrhh = $id_rrhh";

    if ($DB_conn->query($query) === TRUE) {
        echo '<script>alert("Borrado exitoso")</script>';
    } else {
        echo "Error deleting record: " . $DB_conn->error;
        exit;
    }            

    // Redireccionar a crud-rrhh.php incluyendo el valor de $rol como parámetro de consulta
    header("Location: ./crud-rrhh.php?rol=" . urlencode($rol));
}
?>
