<?php
// Obtener el valor de $rol de los parámetros de consulta
if (isset($_GET['rol'])) {
    $rol = $_GET['rol'];
} else {
    // Manejar el caso en que $rol no esté definido en los parámetros de consulta
    $rol = "Valor predeterminado";
}
?>

<?php include ("./header-causa.php"); ?>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<main>
    <div class="container p-4">
        <div class="row">
            <div class="col">
                <button id="btnAgregarNuevo" class="btn btn-dark">
                    <i class="fas fa-plus"></i> Agregar Nuevo Causa
                </button>
                <div id="createCausaForm" style="display: none;">
                    <?php include ("./create-causa.php"); ?>
                </div>
            </div>
            <br>
            <br>
            <div class="col-12" id="readCausaSection">
                <?php
                // Determinar el tipo de causa seleccionado (si es que hay uno)
                $tipo_causa = isset($_GET['tipo_causa']) ? $_GET['tipo_causa'] : '';

                // Incluir el script de lectura correspondiente según el tipo de causa seleccionado
                if ($tipo_causa !== '') {
                    // Si se seleccionó un tipo de causa, incluir el script de lectura correspondiente
                    include("./read-causa.php");
                } else {
                    // Si no se seleccionó un tipo de causa, mostrar un mensaje o realizar otra acción
                    echo "<p>Seleccione un tipo de causa para mostrar los datos.</p>";
                }
                ?>
            </div>
        </div>
    </div>
</main>

<script>
    $(document).ready(function() {
        $("#btnAgregarNuevo").click(function() {
            $("#createCausaForm").toggle();
            $("#readCausaSection").toggle();
        });
    });
</script>

<?php include ("./footer-causa.php"); ?>
