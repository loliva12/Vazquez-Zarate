<?php
// Incluye el archivo de conexión a la base de datos
include 'ludb.php';

// Variable para almacenar el valor de búsqueda
$search = "";

// Si se ha enviado el formulario de búsqueda
if(isset($_POST['search'])) {
    $search = $_POST['search'];
    // Modifica la consulta para incluir la búsqueda por nombre
    $query = "SELECT * FROM eventos WHERE nombre LIKE '%$search%' ORDER BY fecha ASC";
} else {
    // Si no se ha enviado el formulario de búsqueda, realiza una consulta normal
    $query = "SELECT * FROM eventos ORDER BY fecha ASC";
}

$result = mysqli_query($DB_conn, $query);
?>

<!-- Comienza formulario de búsqueda -->
<form method="POST" action="">
    <input type="text" name="search" placeholder="Buscar por nombre..." value="<?php echo $search; ?>">
    <button type="submit" >Buscar</button>
</form>

<!-- Comienza código HTML: read-evento.php -->
<table >
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Horario</th>
            <th>Fecha</th>
            <th>Referencias</th>
            <th>Nombre Abogado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Itera sobre los resultados de la consulta y muestra los registros en la tabla
        while ($register = mysqli_fetch_array($result)) { ?>
            <tr onclick="document.location = './edit-evento.php?id_evento=<?php echo $register['id_evento']; ?>'">
                <td><?php echo $register['id_evento']; ?></td>
                <td><?php echo $register['nombre']; ?></td>
                <td><?php echo $register['horario']; ?></td>
                <td><?php echo $register['fecha']; ?></td>
                <td><?php echo $register['referencia']; ?></td>
                <td><?php echo $register['nombre_abogado']; ?></td>
                <td>
                    <a href="./edit-evento.php?id_evento=<?php echo $register['id_evento']; ?>" class="btn btn-success" title="Editar el registro <?php echo $register['id_evento']; ?>">
                        <!-- icono para editar -->
                        <i class="fas fa-user-edit"></i>
                    </a>
                    <a href="./delete-evento.php?id_evento=<?php echo $register['id_evento']; ?>" class="btn btn-danger" title="Borrar el registro <?php echo $register['id_evento']; ?>">
                        <!-- icono para eliminar -->
                        <i class="fas fa-trash-alt"></i>
                    </a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<!-- Estilos CSS -->
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: #ffff;
    }

    th, td {
        padding: 12px;
        text-align: left;
        border: 1px solid #a3531c;
    }

    th {
        background-color: #ebb48d;
        color: #a3531c;
    }

    tr:hover {
        background-color: #f6ebdd; /* Cambiar color al pasar el mouse sobre la fila */
    }

     /* Estilos para el formulario de búsqueda */
     form {
        margin-bottom: 20px;
    }

    input[type="text"] {
        padding: 8px;
        width: 200px;
    }

    button[type="submit"] {
        padding: 8px 16px;
        background-color: black; /* Color de fondo negro */
        color: white;
        border: none;
        cursor: pointer;
    }

    button[type="submit"]:hover {
        background-color: #333; /* Color más oscuro al pasar el mouse */
    }
</style>
