<?php
// Obtener el valor de $rol y $tipo_causa de los parámetros de consulta
if (isset($_GET['rol'])) {
    $rol = $_GET['rol'];
} else {
    $rol = "Valor predeterminado";
}

if (isset($_GET['tipo_causa'])) {
    $tipo_causa = $_GET['tipo_causa'];
} else {
    $tipo_causa = "Penal"; // Establecer un valor predeterminado si no se proporciona
}
?>

<?php
include('ludb.php'); 
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
    if ($DB_conn) {
        $query = "SELECT c.*, cl.nombre AS nom_cliente
                  FROM causas c
                  INNER JOIN clientes cl ON c.id_cliente = cl.id_cliente
                  WHERE c.estado LIKE '%$searchTerm%' AND c.tipo_causa = '$tipo_causa'
                  ORDER BY c.nombre";
        $result = mysqli_query($DB_conn, $query);
        while ($register = mysqli_fetch_array($result)) { 
            echo "<tr>";
            echo "<td>{$register['nombre']}</td>";
            echo "<td>{$register['descripcion']}</td>";
            echo "<td>{$register['nom_cliente']}</td>";
            echo "<td>{$register['tipo_causa']}</td>";
            echo "<td>{$register['subtipo_causa']}</td>";
            echo "<td>{$register['estado']}</td>";
            echo "<td>";
            // Editar el registro
            echo "<a href='./edit-causa.php?id_causa={$register['id_causa']}&rol=" . urlencode($rol) . "&tipo_causa=" . urlencode($tipo_causa) . "' class='btn btn-success' title='Editar el registro {$register['id_causa']}'>";
            echo "<i class='fas fa-user-edit'></i></a>";
            // Eliminar el registro
            echo "<a href='./delete-causa.php?id_causa={$register['id_causa']}&rol=" . urlencode($rol) . "' class='btn btn-danger' title='Borrar el registro {$register['id_causa']}'>";
            echo "<i class='fas fa-trash-alt'></i></a>";
            echo "</td></tr>";
        }
    } else {
        echo "Database connection not established.";
    }
}
?>
