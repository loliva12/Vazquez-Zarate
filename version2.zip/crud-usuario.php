<?php require_once("./ludb.php"); ?>

<main>
    <div class="container p-4">
        <div class="row justify-content-center">
            <div class="col-4">
                <?php include("./create-usuario.php"); ?>
            </div>
        </div>
    </div>
</main>

<?php include("./footer-usuario.php"); ?>
