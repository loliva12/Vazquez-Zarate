<?php
// Obtener el valor de $rol de los parámetros de consulta
if (isset($_GET['rol'])) {
    $rol = $_GET['rol'];
} else {
    // Manejar el caso en que $rol no esté definido en los parámetros de consulta
    $rol = "Valor predeterminado";
}
?>

<?php
include('ludb.php'); 
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
    if ($DB_conn) {
        $query = "SELECT * FROM rrhh WHERE nombre LIKE '%$searchTerm%' ORDER BY nombre";
        $result = mysqli_query($DB_conn, $query);
        while ($register = mysqli_fetch_array($result)) { 
            echo "<tr>";
            echo "<td>{$register['nombre']}</td>";
            echo "<td>{$register['apellido']}</td>";
            echo "<td>{$register['dni']}</td>";
            echo "<td>{$register['fecha_nacimiento']}</td>";
            echo "<td>{$register['telefono']}</td>";
            echo "<td>{$register['email']}</td>";
            echo "<td>{$register['direccion']}</td>";
            echo "<td>";
            // Editar el registro
            echo "<a href='./edit-rrhh.php?id_rrhh={$register['id_rrhh']}&rol=" . urlencode($rol) . "' class='btn btn-success' title='Editar el registro {$register['id_rrhh']}'>";
            echo "<i class='fas fa-user-edit'></i></a>";
            // Eliminar el registro
            echo "<a href='./delete-rrhh.php?id_rrhh={$register['id_rrhh']}&rol=" . urlencode($rol) . "' class='btn btn-danger' title='Borrar el registro {$register['id_rrhh']}'>";
            echo "<i class='fas fa-trash-alt'></i></a>";
            echo "</td></tr>";
        }
    } else {
        echo "Database connection not established.";
    }
}
?>
