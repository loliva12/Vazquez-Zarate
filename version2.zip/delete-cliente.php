<?php
require_once("./ludb.php");

if (isset($_GET['id_cliente'])) {
    $id_cliente = $_GET['id_cliente'];
    $rol = isset($_GET['rol']) ? $_GET['rol'] : "Valor predeterminado";

    // Verificar si el cliente está asociado a alguna causa
    $causa_query = "SELECT COUNT(*) AS total_causas FROM causas WHERE id_cliente = $id_cliente";
    $causa_result = $DB_conn->query($causa_query);
    $causa_data = $causa_result->fetch_assoc();
    $total_causas = $causa_data['total_causas'];

    if ($total_causas > 0) {
        // Si el cliente está asociado a alguna causa, mostrar un mensaje emergente
        echo '<script>alert("Este cliente está asociado a una o más causas y no se puede borrar.");</script>';
    } else {
        // Si el cliente no está asociado a ninguna causa, proceder con la eliminación
        $delete_query = "DELETE FROM clientes WHERE id_cliente = $id_cliente";

        if ($DB_conn->query($delete_query) === TRUE) {
            // Si se elimina correctamente, mostrar mensaje de éxito
            echo '<script>alert("Borrado exitoso.");</script>';
        } else {
            // Si hay un error, mostrar mensaje de error
            echo '<script>alert("Error al borrar el registro: ' . $DB_conn->error . '");</script>';
        }
    }

    // Redireccionar de regreso a crud-cliente.php
    echo '<script>window.location.href = "./crud-cliente.php?rol=' . urlencode($rol) . '";</script>';
    exit; // Terminar el script después de redireccionar
}
?>
