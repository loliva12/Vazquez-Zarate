<?php
// Obtener el valor de $rol de los parámetros de consulta
if (isset($_GET['rol'])) {
    $rol = $_GET['rol'];
} else {
    // Manejar el caso en que $rol no esté definido en los parámetros de consulta
    $rol = "Valor predeterminado";
}
?>

<!-- Carga de las librerías de JQUERY, POPPER y las despendecias de plugin necesarias -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
<footer>
    <div class="py-4 bg-light mt-auto">
        <div class="container-fluid px-4">
            <div class="d-flex align-items-center justify-content-between small">
                <button type="button" class="btn btn-dark" onclick="location.href='./home.php?rol=<?= urlencode($rol) ?>'">
                    <i class="fa fa-home"></i>
                    <span>Inicio</span>
                </button>
                <!-- Botón para volver a la botonera de las causas -->
                <button type="button" class="btn btn-dark" onclick="location.href='./causas.php?rol=<?= urlencode($rol) ?>'">
                    <i class="fas fa-arrow-left"></i>
                    <span>Volver a Causas</span>
                </button>
            </div>
        </div>
    </div>
</footer>

</html>
